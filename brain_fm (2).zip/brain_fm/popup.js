
chrome.commands.onCommand.addListener(function(command) {

 if (command === "tabless")
{
chrome.tabs.query({}, function(tabs) {
  var doFlag = true;
  for (var i=tabs.length-1; i>=0; i--) {
    if (tabs[i].url == "https://www.brain.fm/app/player") {

      doFlag = false;
             chrome.tabs.update(tabs[i].id, {active: false})
      {

          chrome.tabs.executeScript(tabs[i].id,{code:" document.querySelectorAll('.PlayControl__wrapper___341vD')[0].click();"});

      }; //focus it
      break;
    }
  }
  if (doFlag) { //it didn't found anything, so create it
  var newURL = "https://www.brain.fm/app/player";
        chrome.tabs.create({ url: newURL });
  }
});
}

});


chrome.tabs.onCreated.addListener(function(activeInfo)
 {
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {

        var last2 = changeInfo.url;
           if (last2 == "https://www.brain.fm/app/player")
       {
    chrome.tabs.executeScript(null,{code:" document.querySelectorAll('.PlayControl__wrapper___341vD')[0].click();"});

       }
});
});







